package com.nosswess.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

data class Video(val url: String, val author: String, val caption: String)

// Vidéos d'exemple (à remplacer plus tard par celles de vos utilisateurs via Firebase).
val sampleVideos = listOf(
    Video(
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        "@nosswess", "Bienvenue sur Noss Wess !"
    ),
    Video(
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "@nosswess", "Deuxième vidéo d'exemple"
    ),
    Video(
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        "@nosswess", "Troisième vidéo d'exemple"
    ),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FeedScreen(sampleVideos) }
    }
}

@Composable
fun FeedScreen(videos: List<Video>) {
    val pagerState = rememberPagerState(pageCount = { videos.size })
    VerticalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize().background(Color.Black)
    ) { page ->
        VideoPage(videos[page], isCurrent = pagerState.currentPage == page)
    }
}

@Composable
fun VideoPage(video: Video, isCurrent: Boolean) {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.url))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
        }
    }
    DisposableEffect(isCurrent) {
        player.playWhenReady = isCurrent
        onDispose { }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var liked by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
        ) {
            Text(video.author, color = Color.White, fontSize = 18.sp)
            Text(video.caption, color = Color.White, fontSize = 14.sp)
        }
        Column(
            modifier = Modifier.align(Alignment.CenterEnd).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(onClick = { liked = !liked }) {
                Icon(
                    Icons.Filled.Favorite, contentDescription = "J'aime",
                    tint = if (liked) Color.Red else Color.White
                )
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.ChatBubble, contentDescription = "Commentaires", tint = Color.White)
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.Share, contentDescription = "Partager", tint = Color.White)
            }
        }
    }
}
