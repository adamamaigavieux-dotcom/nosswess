package com.nosswess.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

data class Video(val uri: String, val author: String, val caption: String)

private const val PREFS = "nosswess"
private const val KEY_VIDEOS = "videos"

private fun loadVideos(prefs: SharedPreferences): List<Video> =
    (prefs.getString(KEY_VIDEOS, "") ?: "")
        .split("\n")
        .filter { it.isNotBlank() }
        .map { Video(it, "@nosswess", "Ma vidéo") }

private fun saveVideos(prefs: SharedPreferences, videos: List<Video>) {
    prefs.edit().putString(KEY_VIDEOS, videos.joinToString("\n") { it.uri }).apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NossWessApp() }
    }
}

@Composable
fun NossWessApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val videos = remember { mutableStateListOf<Video>().apply { addAll(loadVideos(prefs)) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null && videos.none { it.uri == uri.toString() }) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            videos.add(0, Video(uri.toString(), "@nosswess", "Ma vidéo"))
            saveVideos(prefs, videos)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (videos.isEmpty()) {
            Text(
                "Bienvenue sur Noss Wess !\n\nAppuyez sur + pour publier votre première vidéo.",
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(32.dp)
            )
        } else {
            FeedScreen(
                videos = videos,
                onDelete = { video ->
                    videos.remove(video)
                    saveVideos(prefs, videos)
                }
            )
        }
        FloatingActionButton(
            onClick = { picker.launch(arrayOf("video/*")) },
            modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = "Publier une vidéo")
        }
    }
}

@Composable
fun FeedScreen(videos: List<Video>, onDelete: (Video) -> Unit) {
    val pagerState = rememberPagerState(pageCount = { videos.size })
    VerticalPager(
        state = pagerState,
        key = { videos[it].uri },
        modifier = Modifier.fillMaxSize().background(Color.Black)
    ) { page ->
        VideoPage(
            video = videos[page],
            isCurrent = pagerState.currentPage == page,
            onDelete = { onDelete(videos[page]) }
        )
    }
}

@Composable
fun VideoPage(video: Video, isCurrent: Boolean, onDelete: () -> Unit) {
    val context = LocalContext.current
    var error by remember { mutableStateOf(false) }
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(video.uri)))
            repeatMode = Player.REPEAT_MODE_ONE
            addListener(object : Player.Listener {
                override fun onPlayerError(e: PlaybackException) {
                    error = true
                }
            })
            prepare()
        }
    }
    DisposableEffect(isCurrent) {
        player.playWhenReady = isCurrent
        onDispose { }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var liked by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (error) {
            Text(
                "Impossible de lire cette vidéo",
                color = Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(video.author, color = Color.White, fontSize = 18.sp)
            Text(video.caption, color = Color.White, fontSize = 14.sp)
        }
        Column(
            modifier = Modifier.align(Alignment.CenterEnd).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(onClick = { liked = !liked }) {
                Icon(
                    Icons.Filled.Favorite, contentDescription = "J'aime",
                    tint = if (liked) Color.Red else Color.White
                )
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.ChatBubble, contentDescription = "Commentaires", tint = Color.White)
            }
            IconButton(onClick = { }) {
                Icon(Icons.Filled.Share, contentDescription = "Partager", tint = Color.White)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = Color.White)
            }
        }
    }
}
